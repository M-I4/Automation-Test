# OrangeHRM Automation Project

## Setup
1. Install Java 11+ and Maven
2. Install Chrome and ChromeDriver (update path in BaseTest.java if needed)
3. Import this Maven project into Eclipse

## Run Tests
- Right-click `testng.xml` → Run as TestNG Suite
- Or run using `mvn test`
